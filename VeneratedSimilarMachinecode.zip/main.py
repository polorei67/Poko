a = input("+ or - or * or /  :  ")

b = input("say number one")

c = input("say number two")

if a == ("+"):
  print(float(b) + float(c))

elif a == ("-"):
  print(float(b) - float(c))

elif a == ("*"):
  print(float(b) * float(c))

elif a == ("/"):
  print(float(b) / float(c))